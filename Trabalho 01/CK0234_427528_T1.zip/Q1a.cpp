#include "fibo.h"

int main(int argc, char *argv[ ]){

	calcular(atoi(argv[1]), atoi(argv[2]));
	cout << "\n";	
  
    return 0;
}
