package main;

public interface ICalcular {
	double resolver(double valor1, double valor2);
}